package com.jetgo.tv.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.PlayerView
import com.jetgo.tv.data.model.Category
import com.jetgo.tv.data.model.Channel
import com.jetgo.tv.data.model.ContentItem
import com.jetgo.tv.player.PlayerManager
import com.jetgo.tv.ui.screens.HomeViewModel

/**
 * Reproductor a pantalla completa (horizontal). Se muestra por encima de toda la demás UI
 * cuando el usuario toca el reproductor normal.
 *
 * Para películas/series/anime ([isVod] = true) muestra los controles completos (play/pausa,
 * avance/retroceso, barra de progreso, idioma/subtítulos).
 *
 * Para canales en vivo ([isVod] = false) muestra el banner de programación (EPG) al cambiar
 * de canal, y permite abrir el panel lateral de canales/categorías presionando IZQUIERDA en
 * el control remoto (1 vez = canales, 2 veces = categorías). Con el panel abierto: ARRIBA/ABAJO
 * mueve la selección y el CENTRO/OK del control confirma (cambia de canal o entra a la categoría).
 */
@Composable
fun FullscreenPlayerOverlay(
    playerManager: PlayerManager,
    onExitFullscreen: () -> Unit,
    isVod: Boolean = false,
    posterUrl: String? = null,
    title: String = "",
    liveChannelInfo: HomeViewModel.LiveChannelInfo? = null,
    allLiveChannels: List<Channel> = emptyList(),
    onChangeChannel: (Channel) -> Unit = {},
    liveCategories: List<Category> = emptyList(),
    liveChannelsInCategory: List<ContentItem> = emptyList(),
    onLoadLiveCategories: () -> Unit = {},
    onSelectLiveCategory: (String) -> Unit = {},
    onSelectLiveChannel: (ContentItem) -> Unit = {},
    showNextEpisodeMessage: Boolean = false
) {
    var showLanguageDialog by remember { mutableStateOf(false) }
    var zapMode by remember { mutableStateOf(ZapPanelMode.HIDDEN) }
    var zapSelectedIndex by remember { mutableStateOf(0) }
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(isVod) {
        if (!isVod) {
            onLoadLiveCategories()
            try { focusRequester.requestFocus() } catch (e: Exception) { /* ignorar si aún no está listo */ }
        }
    }

    // Al cambiar de modo (canales <-> categorías), la selección arranca en el primer elemento
    LaunchedEffect(zapMode) {
        zapSelectedIndex = 0
    }

    fun confirmCategorySelection() {
        liveCategories.getOrNull(zapSelectedIndex)?.let { category ->
            onSelectLiveCategory(category.id)
            zapMode = ZapPanelMode.CHANNELS
        }
    }

    fun confirmChannelSelection() {
        liveChannelsInCategory.getOrNull(zapSelectedIndex)?.let { channel ->
            onSelectLiveChannel(channel)
            zapMode = ZapPanelMode.HIDDEN
        }
    }

    /** Cambia de canal directo, como el botón CH+/CH- de un control de TV normal */
    fun changeChannelDirect(step: Int) {
        if (allLiveChannels.isEmpty()) return
        val currentIndex = allLiveChannels.indexOfFirst { it.streamId == liveChannelInfo?.channelId }
        val nextIndex = if (currentIndex == -1) 0
        else ((currentIndex + step) % allLiveChannels.size + allLiveChannels.size) % allLiveChannels.size
        onChangeChannel(allLiveChannels[nextIndex])
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .then(
                if (!isVod) {
                    Modifier
                        .focusRequester(focusRequester)
                        .onFocusChanged { focusState ->
                            // Si algo más le robó el foco (ej. el botón de salir), lo recuperamos
                            // para que el control remoto siga funcionando en la pantalla completa.
                            if (!focusState.isFocused) {
                                try { focusRequester.requestFocus() } catch (e: Exception) { /* ignorar */ }
                            }
                        }
                        .focusable()
                        .onKeyEvent { event ->
                            if (event.type != KeyEventType.KeyDown) return@onKeyEvent false
                            when (event.key) {
                                Key.ChannelUp -> { changeChannelDirect(1); true }
                                Key.ChannelDown -> { changeChannelDirect(-1); true }
                                Key.DirectionLeft -> {
                                    zapMode = when (zapMode) {
                                        ZapPanelMode.HIDDEN -> ZapPanelMode.CHANNELS
                                        ZapPanelMode.CHANNELS -> ZapPanelMode.CATEGORIES
                                        ZapPanelMode.CATEGORIES -> ZapPanelMode.HIDDEN
                                    }
                                    true
                                }
                                Key.DirectionUp -> {
                                    if (zapMode != ZapPanelMode.HIDDEN) {
                                        zapSelectedIndex = (zapSelectedIndex - 1).coerceAtLeast(0)
                                    } else {
                                        changeChannelDirect(-1) // como el canal - de una tele normal
                                    }
                                    true
                                }
                                Key.DirectionDown -> {
                                    if (zapMode != ZapPanelMode.HIDDEN) {
                                        val maxIndex = (
                                            if (zapMode == ZapPanelMode.CATEGORIES) liveCategories.size
                                            else liveChannelsInCategory.size
                                            ) - 1
                                        zapSelectedIndex = (zapSelectedIndex + 1).coerceAtMost(maxIndex.coerceAtLeast(0))
                                    } else {
                                        changeChannelDirect(1) // como el canal + de una tele normal
                                    }
                                    true
                                }
                                Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> {
                                    when (zapMode) {
                                        ZapPanelMode.CATEGORIES -> { confirmCategorySelection(); true }
                                        ZapPanelMode.CHANNELS -> { confirmChannelSelection(); true }
                                        ZapPanelMode.HIDDEN -> false
                                    }
                                }
                                Key.Back -> {
                                    if (zapMode != ZapPanelMode.HIDDEN) {
                                        zapMode = ZapPanelMode.HIDDEN
                                        true
                                    } else false
                                }
                                else -> false
                            }
                        }
                } else Modifier
            )
    ) {
        AndroidView(
            factory = { context ->
                PlayerView(context).apply {
                    player = playerManager.exoPlayer
                    useController = false
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        if (isVod) {
            VodPlayerControls(
                playerManager = playerManager,
                posterUrl = posterUrl,
                title = title,
                onExit = onExitFullscreen,
                onOpenLanguageMenu = { showLanguageDialog = true }
            )
            if (showNextEpisodeMessage) {
                Box(
                    modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "Siguiente capítulo",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                    )
                }
            }
        } else {
            IconButton(
                onClick = onExitFullscreen,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(16.dp)
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.5f))
                    .focusProperties { canFocus = false }
            ) {
                Icon(
                    imageVector = Icons.Default.FullscreenExit,
                    contentDescription = "Salir de pantalla completa",
                    tint = Color.White
                )
            }

            liveChannelInfo?.let { info ->
                LiveChannelInfoBanner(
                    info = info,
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
            }

            LiveZapPanel(
                mode = zapMode,
                categories = liveCategories,
                channels = liveChannelsInCategory,
                currentChannelName = liveChannelInfo?.channelName ?: "",
                selectedIndex = zapSelectedIndex,
                onSelectCategory = { category ->
                    onSelectLiveCategory(category.id)
                    zapMode = ZapPanelMode.CHANNELS
                },
                onSelectChannel = { channel ->
                    onSelectLiveChannel(channel)
                    zapMode = ZapPanelMode.HIDDEN
                },
                modifier = Modifier.align(Alignment.CenterStart)
            )
        }
    }

    if (showLanguageDialog) {
        LanguageTracksDialog(
            audioTracks = playerManager.getAudioTracks(),
            subtitleTracks = playerManager.getSubtitleTracks(),
            onSelectAudio = { playerManager.selectTrack(it); showLanguageDialog = false },
            onSelectSubtitle = { playerManager.selectSubtitleTrack(it); showLanguageDialog = false },
            onDisableSubtitles = { playerManager.disableSubtitles(); showLanguageDialog = false },
            onDismiss = { showLanguageDialog = false }
        )
    }
}
